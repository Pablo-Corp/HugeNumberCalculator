var searchData=
[
  ['previous_112',['previous',['../struct_node.html#a59034527ab4d35d7406dd2caa492d71f',1,'Node']]]
];
